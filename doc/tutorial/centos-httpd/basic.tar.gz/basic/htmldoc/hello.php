<html>
<body>

Hello <?php echo $_POST["name"]; ?>!<br>
Your email is <?php echo $_POST["email"]; ?><br>

<a href="index.html">back</a>

</body>
</html>
