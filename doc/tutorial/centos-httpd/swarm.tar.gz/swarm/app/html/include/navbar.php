<header>
	<nav class="navbar navbar-expand-md fixed-top navbar-dark bg-dark">
  	<!-- Links -->
  	<ul class="navbar-nav">
    		<li class="nav-item"><a class="nav-link" href="index.php">Register</a></li>
    		<li class="nav-item"><a class="nav-link" href="report.php">Report</a></li>
	</ul>
	</nav>
</header>
