#!/bin/bash
#
# this script removes persisetent data created in exercises

sudo rm -rf ./data ./log
