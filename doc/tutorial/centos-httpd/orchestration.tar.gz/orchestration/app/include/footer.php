<footer class="footer">
	<div class="container">
	<span class="text-muted"><?php echo "Served by host: ". gethostname(); ?></span>
	</div>
</footer>
